# Overhaul lib

All the code from Combat Overhaul mod was moved to this library, so other my mods can reuse it without depending on CO.

This library is not meant to be used by other modders, was never designed for this purpose. It has no documentation and the solution is tailored for my installation.
However nothing actually prevents you from using this library as a required dependency.